import logging
import os
import time

from wxpy import *

bot = Bot()
print("*********************************")
print("*******微信机器人-测试版本*******")
print("*********************************")
# 自动接受新的好友请求
@bot.register(msg_types=FRIENDS)
def auto_accept_friends(msg):
    if '我要入群' in msg.text.lower():
        # 接受好友请求
        new_friend = msg.card.accept()
        # 向新的好友发送消息
        new_friend.send('Hello，欢迎欢迎！！')
        my_group = bot.groups().search('ㄧ道去台灣粉絲群1️')[0]
        # my_group = bot.groups().search('测试1️')[0]
        my_group.add_members(new_friend)
        print(new_friend.name,'成功入群')
 # 进入 Python 命令行、让程序保持运行
# embed()
bot.join()
